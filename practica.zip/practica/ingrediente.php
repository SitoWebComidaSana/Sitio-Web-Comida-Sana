<?php

class Ingrediente
{
	
	private $id_ingrediente;
	private $descripcion;

	
	function __construct($id_ingrediente, $descripcion)
	{
		$this->id_ingrediente = $id_ingrediente;
		$this->descripcion = $descripcion;
	}

	
	function getIdingrediente()
	{
		return $this->id_ingrediente;
	}


	function getDescripcion()
	{
		return $this->descripcion;
	}


}


?>