<?php

include_once('ingrediente.php');
include_once('clsConexion.php');

class ingrediente_collector
{
	public function mostrar()
    {
        $objConexion=new clsConexion();
        $sql="SELECT id_ingrediente FROM tbl_ingrediente ";
        $resultset_ingrediente = $objConexion->EjecutarSQL($sql);
        return $resultset_ingrediente;
    }


}



?>